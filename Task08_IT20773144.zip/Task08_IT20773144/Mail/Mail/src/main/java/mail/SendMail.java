
import mail.Mailer;


public class SendMail {
        
 public static void main(String[] args) {    
     //from,password,to,subject,message  
     Mailer.send("thanuzsenthilkumar@gmail.com","#Thanuz@1827","thanuzsenthil09@gmail.com","Rust Repair mangement System Notification!","  Your job completed, \n Thank You.");  
     //change 1Gmail, 2password  3to 4subject 5Message  
 }    
}  
    

